# from flask import Blueprint, request, jsonify, Response, render_template
# from .models import db, SensorReading, DeviceHealth
# from .ml import predict_all_models, ensemble_predict, has_any_model
# from datetime import datetime
# import json
# import csv
# import io
# import requests

# api_bp = Blueprint('api', __name__)
# DASHBOARD_URL = "https://aqmrg-frontend.vercel.app/api/v1/data/ingest"

# @api_bp.route('/')
# def home():
#     return render_template('index.html')

# @api_bp.route('/health', methods=['GET'])
# def health():
#     return jsonify({"status": "healthy", "service": "local-sensor-receiver"})

# @api_bp.route('/api/v1/devices', methods=['GET'])
# def get_devices():
#     """Get a list of all distinct device IDs actively reporting to the base."""
#     # Query unique device IDs starting with 'AQ-'
#     device_ids = [r[0] for r in db.session.query(SensorReading.device_id)
#                  .filter(SensorReading.device_id.like('AQ-%'))
#                  .distinct().all()]

#     devices = []
#     for d_id in device_ids:
#         # Fetch the latest reading for coordinates
#         latest = SensorReading.query.filter_by(device_id=d_id).order_by(SensorReading.timestamp.desc()).first()
#         devices.append({
#             "device_id": d_id,
#             "name": "Nairobi Estate Station" if d_id.startswith('AQ-') else d_id,
#             "latitude": latest.latitude if latest else -1.294584,
#             "longitude": latest.longitude if latest else 36.726746,
#             "is_verified": True
#         })

#     return jsonify({"devices": devices})

# @api_bp.route('/api/v1/data/ingest', methods=['POST'])
# def ingest():
#     try:
#         data = request.get_json()
#         if not data: return jsonify({"status": "error"}), 400

#         # Strict hardware lock: Only allow 'AQ-' prefix devices
#         device_id = data.get('sensorId', data.get('device_id', 'unknown'))
#         if not device_id.startswith('AQ-'):
#             return jsonify({"status": "ignored", "message": f"Device {device_id} not whitelisted"}), 200

#         metrics = data.get('metrics', {}); loc = data.get('location', {})
#         pm10 = metrics.get('pm10', 0)
#         co = metrics.get('co', 0)
#         temperature = metrics.get('temperature', 0)
#         humidity = metrics.get('humidity', 0)

#         preds = predict_all_models(pm10, co, temperature, humidity)
#         ensemble = ensemble_predict(pm10, co, temperature, humidity)

#         new_reading = SensorReading(
#             device_id=device_id,
#             pm1=metrics.get('pm1'), pm25=metrics.get('pm25'), pm10=pm10,
#             co=co, co2=metrics.get('co2'),
#             temperature=temperature, humidity=humidity,
#             voc_index=metrics.get('voc_index'), nox_index=metrics.get('nox_index'),
#             latitude=data.get('latitude', loc.get('latitude')),
#             longitude=data.get('longitude', loc.get('longitude')),
#             raw_payload=json.dumps(data),
#             predicted_pm25=ensemble,
#             predicted_pm25_existing=preds.get('existing'),
#             predicted_pm25_gb=preds.get('gb'),
#             predicted_pm25_ols=preds.get('ols')
#         )
#         db.session.add(new_reading)

#         health_data = data.get('health')
#         if health_data:
#             new_health = DeviceHealth(
#                 device_id=device_id,
#                 uptime_minutes=health_data.get('uptime_minutes'),
#                 signal_dbm=health_data.get('signal_dbm'),
#                 gsm_reconnects=health_data.get('gsm_reconnects'),
#                 failed_requests=health_data.get('failed_requests'),
#                 last_http_status=health_data.get('last_http_status'),
#                 issues=json.dumps(health_data.get('issue_descriptions', [])),
#                 sensor_status=json.dumps(health_data.get('sensors', {}))
#             )
#             db.session.add(new_health)

#         db.session.commit()

#         try:
#             requests.post(DASHBOARD_URL, json=data, timeout=3)
#         except Exception:
#             pass

#         return jsonify({"status": "success", "id": new_reading.id}), 201
#     except Exception as e:
#         return jsonify({"status": "error", "message": str(e)}), 500

# @api_bp.route('/api/v1/forecast/realtime', methods=['GET'])
# def get_prediction():
#     if not has_any_model():
#         return jsonify({"status": "error", "message": "No models loaded"}), 500

#     latest = SensorReading.query.order_by(SensorReading.timestamp.desc()).first()
#     if not latest:
#         return jsonify({"status": "error", "message": "No sensor data found"}), 404

#     try:
#         pred = ensemble_predict(
#             latest.pm10 or 0,
#             latest.co or 0,
#             latest.temperature or 0,
#             latest.humidity or 0
#         )
#         if pred is None:
#             return jsonify({"status": "error", "message": "All models failed"}), 500

#         return jsonify({
#             "prediction": pred,
#             "actual_pm25": latest.pm25,
#             "shift": round(latest.pm25 - pred, 2),
#             "timestamp": latest.timestamp.strftime('%Y-%m-%d %H:%M:%S')
#         })
#     except Exception as e:
#         return jsonify({"status": "error", "message": str(e)}), 500

# @api_bp.route('/api/v1/forecast/comparison', methods=['GET'])
# def get_model_comparison():
#     if not has_any_model():
#         return jsonify({"status": "error", "message": "No models loaded"}), 500

#     latest = SensorReading.query.order_by(SensorReading.timestamp.desc()).first()
#     if not latest:
#         return jsonify({"status": "error", "message": "No sensor data found"}), 404

#     if latest.predicted_pm25_gb is not None and latest.predicted_pm25_ols is not None:
#         preds = {
#             'existing': latest.predicted_pm25_existing,
#             'gb': latest.predicted_pm25_gb,
#             'ols': latest.predicted_pm25_ols
#         }
#     else:
#         preds = predict_all_models(
#             latest.pm10 or 0,
#             latest.co or 0,
#             latest.temperature or 0,
#             latest.humidity or 0
#         )

#     import numpy as np
#     valid_preds = [v for v in preds.values() if v is not None]
#     ensemble_median = round(float(np.median(valid_preds)), 2) if valid_preds else None

#     return jsonify({
#         "timestamp": latest.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
#         "actual_pm25": latest.pm25,
#         "predictions": preds,
#         "ensemble_median": ensemble_median
#     })

# @api_bp.route('/api/v1/data/latest', methods=['GET'])
# def get_latest():
#     device_id = request.args.get('device_id')
#     query = SensorReading.query
#     if device_id:
#         query = query.filter_by(device_id=device_id)
#     readings = query.order_by(SensorReading.timestamp.desc()).limit(100).all()
#     return jsonify([r.to_dict() for r in readings])

# @api_bp.route('/api/v1/history/all', methods=['GET'])
# def get_all_history():
#     device_id = request.args.get('device_id')
#     query = SensorReading.query
#     if device_id:
#         query = query.filter_by(device_id=device_id)
#     readings = query.order_by(SensorReading.timestamp.desc()).all()
#     return jsonify({"readings": [r.to_dict() for r in readings]})

# @api_bp.route('/api/v1/health/latest', methods=['GET'])
# def get_latest_health():
#     device_id = request.args.get('device_id')
#     query = DeviceHealth.query
#     if device_id:
#         query = query.filter_by(device_id=device_id)
#     else:
#         # Filter for all verified node health
#         query = query.filter(DeviceHealth.device_id.like('AQ-%'))

#     health_logs = query.order_by(DeviceHealth.timestamp.desc()).limit(100).all()
#     return jsonify([h.to_dict() for h in health_logs])

# @api_bp.route('/api/v1/data/export/csv', methods=['GET'])
# def export_csv():
#     try:
#         device_id = request.args.get('device_id')
#         query = SensorReading.query
#         if device_id:
#             query = query.filter_by(device_id=device_id)

#         readings = query.order_by(SensorReading.timestamp.desc()).all()

#         output = io.StringIO()
#         writer = csv.writer(output)

#         writer.writerow([
#             'ID', 'Timestamp (EAT)', 'Device ID',
#             'PM1', 'PM2.5', 'PM10',
#             'CO', 'CO2', 'Temperature', 'Humidity',
#             'VOC Index', 'NOx Index', 'Latitude', 'Longitude', 'Predicted PM2.5 (Ensemble)',
#             'Predicted Existing', 'Predicted GB', 'Predicted OLS'
#         ])

#         for r in readings:
#             writer.writerow([
#                 r.id, r.timestamp.strftime('%Y-%m-%d %H:%M:%S'), r.device_id,
#                 r.pm1, r.pm25, r.pm10,
#                 r.co, r.co2, r.temperature, r.humidity,
#                 r.voc_index, r.nox_index, r.latitude, r.longitude,
#                 r.predicted_pm25,
#                 r.predicted_pm25_existing, r.predicted_pm25_gb, r.predicted_pm25_ols
#             ])

#         output.seek(0)
#         prefix = f"{device_id}_" if device_id else ""
#         filename = f"{prefix}aqmrg_relay_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"

#         return Response(output.getvalue(), mimetype="text/csv", headers={"Content-disposition": f"attachment; filename={filename}"})
#     except Exception as e:
#         return jsonify({"status": "error", "message": str(e)}), 500

# @api_bp.route('/api/v1/health/export/csv', methods=['GET'])
# def export_health_csv():
#     try:
#         device_id = request.args.get('device_id')
#         query = DeviceHealth.query
#         if device_id:
#             query = query.filter_by(device_id=device_id)

#         health_logs = query.order_by(DeviceHealth.timestamp.desc()).all()

#         output = io.StringIO()
#         writer = csv.writer(output)

#         writer.writerow([
#             'ID', 'Timestamp (EAT)', 'Device ID',
#             'Uptime (Mins)', 'Signal (dBm)', 'GSM Reconnects',
#             'Failed Requests', 'Last HTTP Status', 'Sensor Statuses', 'Diagnostic Issues'
#         ])

#         for h in health_logs:
#             writer.writerow([
#                 h.id, h.timestamp.strftime('%Y-%m-%d %H:%M:%S'), h.device_id,
#                 h.uptime_minutes, h.signal_dbm, h.gsm_reconnects,
#                 h.failed_requests, h.last_http_status,
#                 h.sensor_status, h.issues
#             ])

#         output.seek(0)
#         prefix = f"{device_id}_" if device_id else ""
#         filename = f"{prefix}aqmrg_health_diagnostics_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"

#         return Response(output.getvalue(), mimetype="text/csv", headers={"Content-disposition": f"attachment; filename={filename}"})
#     except Exception as e:
#         return jsonify({"status": "error", "message": str(e)}), 500





from flask import Blueprint, request, jsonify, Response, render_template
from .models import db, SensorReading, DeviceHealth
from .ml import predict_all_models, ensemble_predict, has_any_model
from datetime import datetime
import json
import csv
import io
import requests

api_bp = Blueprint('api', __name__)
DASHBOARD_URL = "https://aqmrg-frontend.vercel.app/api/v1/data/ingest"

@api_bp.route('/')
def home():
    return render_template('index.html')

@api_bp.route('/health', methods=['GET'])
def health():
    return jsonify({"status": "healthy", "service": "local-sensor-receiver"})

@api_bp.route('/api/v1/devices', methods=['GET'])
def get_devices():
    """Get a list of all distinct device IDs actively reporting to the base."""
    # Strict hardware lock: Only return 'AQ-NODE-001' if it has reported in the last 24h
    active_devices = [r[0] for r in db.session.query(SensorReading.device_id)
                     .filter(SensorReading.device_id == 'AQ-NODE-001')
                     .distinct().all()]
    return jsonify({"devices": active_devices})

@api_bp.route('/api/v1/data/ingest', methods=['POST'])
def ingest():
    try:
        data = request.get_json()
        if not data: return jsonify({"status": "error"}), 400
        metrics = data.get('metrics', {}); loc = data.get('location', {})

        pm10 = metrics.get('pm10', 0)
        co = metrics.get('co', 0)
        temperature = metrics.get('temperature', 0)
        humidity = metrics.get('humidity', 0)

        preds = predict_all_models(pm10, co, temperature, humidity)
        ensemble = ensemble_predict(pm10, co, temperature, humidity)

        new_reading = SensorReading(
            device_id=data.get('sensorId', 'unknown'),
            pm1=metrics.get('pm1'), pm25=metrics.get('pm25'), pm10=pm10,
            co=co, co2=metrics.get('co2'),
            temperature=temperature, humidity=humidity,
            voc_index=metrics.get('voc_index'), nox_index=metrics.get('nox_index'),
            latitude=loc.get('latitude'), longitude=loc.get('longitude'),
            raw_payload=json.dumps(data),
            predicted_pm25=ensemble,
            predicted_pm25_existing=preds.get('existing'),
            predicted_pm25_gb=preds.get('gb'),
            predicted_pm25_ols=preds.get('ols')
        )
        db.session.add(new_reading)

        health_data = data.get('health')
        if health_data:
            new_health = DeviceHealth(
                device_id=data.get('sensorId', 'unknown'),
                uptime_minutes=health_data.get('uptime_minutes'),
                signal_dbm=health_data.get('signal_dbm'),
                gsm_reconnects=health_data.get('gsm_reconnects'),
                failed_requests=health_data.get('failed_requests'),
                last_http_status=health_data.get('last_http_status'),
                issues=json.dumps(health_data.get('issue_descriptions', [])),
                sensor_status=json.dumps(health_data.get('sensors', {}))
            )
            db.session.add(new_health)

        db.session.commit()

        try:
            requests.post(DASHBOARD_URL, json=data, timeout=3)
        except Exception:
            pass

        return jsonify({"status": "success", "id": new_reading.id}), 201
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@api_bp.route('/api/v1/forecast/realtime', methods=['GET'])
def get_prediction():
    if not has_any_model():
        return jsonify({"status": "error", "message": "No models loaded"}), 500

    latest = SensorReading.query.order_by(SensorReading.timestamp.desc()).first()
    if not latest:
        return jsonify({"status": "error", "message": "No sensor data found"}), 404

    try:
        pred = ensemble_predict(
            latest.pm10 or 0,
            latest.co or 0,
            latest.temperature or 0,
            latest.humidity or 0
        )
        if pred is None:
            return jsonify({"status": "error", "message": "All models failed"}), 500

        return jsonify({
            "prediction": pred,
            "actual_pm25": latest.pm25,
            "shift": round(latest.pm25 - pred, 2),
            "timestamp": latest.timestamp.strftime('%Y-%m-%d %H:%M:%S')
        })
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@api_bp.route('/api/v1/forecast/comparison', methods=['GET'])
def get_model_comparison():
    if not has_any_model():
        return jsonify({"status": "error", "message": "No models loaded"}), 500

    latest = SensorReading.query.order_by(SensorReading.timestamp.desc()).first()
    if not latest:
        return jsonify({"status": "error", "message": "No sensor data found"}), 404

    if latest.predicted_pm25_gb is not None and latest.predicted_pm25_ols is not None:
        preds = {
            'existing': latest.predicted_pm25_existing,
            'gb': latest.predicted_pm25_gb,
            'ols': latest.predicted_pm25_ols
        }
    else:
        preds = predict_all_models(
            latest.pm10 or 0,
            latest.co or 0,
            latest.temperature or 0,
            latest.humidity or 0
        )

    import numpy as np
    valid_preds = [v for v in preds.values() if v is not None]
    ensemble_median = round(float(np.median(valid_preds)), 2) if valid_preds else None

    return jsonify({
        "timestamp": latest.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
        "actual_pm25": latest.pm25,
        "predictions": preds,
        "ensemble_median": ensemble_median
    })

@api_bp.route('/api/v1/data/latest', methods=['GET'])
def get_latest():
    device_id = request.args.get('device_id')
    query = SensorReading.query
    if device_id:
        query = query.filter_by(device_id=device_id)
    readings = query.order_by(SensorReading.timestamp.desc()).limit(100).all()
    return jsonify([r.to_dict() for r in readings])

@api_bp.route('/api/v1/history/all', methods=['GET'])
def get_all_history():
    device_id = request.args.get('device_id')
    query = SensorReading.query
    if device_id:
        query = query.filter_by(device_id=device_id)
    readings = query.order_by(SensorReading.timestamp.desc()).all()
    return jsonify({"readings": [r.to_dict() for r in readings]})

@api_bp.route('/api/v1/health/latest', methods=['GET'])
def get_latest_health():
    device_id = request.args.get('device_id')
    query = DeviceHealth.query
    if device_id:
        query = query.filter_by(device_id=device_id)
    else:
        # Strict filter: Only show health for the real node
        query = query.filter(DeviceHealth.device_id == 'AQ-NODE-001')

    health_logs = query.order_by(DeviceHealth.timestamp.desc()).limit(100).all()
    return jsonify([h.to_dict() for h in health_logs])

@api_bp.route('/api/v1/data/export/csv', methods=['GET'])
def export_csv():
    try:
        device_id = request.args.get('device_id')
        query = SensorReading.query
        if device_id:
            query = query.filter_by(device_id=device_id)

        readings = query.order_by(SensorReading.timestamp.desc()).all()

        output = io.StringIO()
        writer = csv.writer(output)

        writer.writerow([
            'ID', 'Timestamp (EAT)', 'Device ID',
            'PM1', 'PM2.5', 'PM10',
            'CO', 'CO2', 'Temperature', 'Humidity',
            'VOC Index', 'NOx Index', 'Latitude', 'Longitude', 'Predicted PM2.5 (Ensemble)',
            'Predicted Existing', 'Predicted GB', 'Predicted OLS'
        ])

        for r in readings:
            writer.writerow([
                r.id, r.timestamp.strftime('%Y-%m-%d %H:%M:%S'), r.device_id,
                r.pm1, r.pm25, r.pm10,
                r.co, r.co2, r.temperature, r.humidity,
                r.voc_index, r.nox_index, r.latitude, r.longitude,
                r.predicted_pm25,
                r.predicted_pm25_existing, r.predicted_pm25_gb, r.predicted_pm25_ols
            ])

        output.seek(0)
        prefix = f"{device_id}_" if device_id else ""
        filename = f"{prefix}aqmrg_relay_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"

        return Response(output.getvalue(), mimetype="text/csv", headers={"Content-disposition": f"attachment; filename={filename}"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@api_bp.route('/api/v1/health/export/csv', methods=['GET'])
def export_health_csv():
    try:
        device_id = request.args.get('device_id')
        query = DeviceHealth.query
        if device_id:
            query = query.filter_by(device_id=device_id)

        health_logs = query.order_by(DeviceHealth.timestamp.desc()).all()

        output = io.StringIO()
        writer = csv.writer(output)

        writer.writerow([
            'ID', 'Timestamp (EAT)', 'Device ID',
            'Uptime (Mins)', 'Signal (dBm)', 'GSM Reconnects',
            'Failed Requests', 'Last HTTP Status', 'Sensor Statuses', 'Diagnostic Issues'
        ])

        for h in health_logs:
            writer.writerow([
                h.id, h.timestamp.strftime('%Y-%m-%d %H:%M:%S'), h.device_id,
                h.uptime_minutes, h.signal_dbm, h.gsm_reconnects,
                h.failed_requests, h.last_http_status,
                h.sensor_status, h.issues
            ])

        output.seek(0)
        prefix = f"{device_id}_" if device_id else ""
        filename = f"{prefix}aqmrg_health_diagnostics_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"

        return Response(output.getvalue(), mimetype="text/csv", headers={"Content-disposition": f"attachment; filename={filename}"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500
